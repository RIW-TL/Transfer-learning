#' @title Identify Selected Sample Indices
#'
#' @param n.vec A vector of sample size across sources
#' @param k.vec A scalar of source id
#'
#' @return
#' \item{id}{vector of utilized samples}
#' @export
#' @examples
#' id = ind.set(n.vec = rep(100,5), k.vec = 3)
#' print(id)
ind.set = function(n.vec, k.vec){
  ind.re <- NULL
  for(k in k.vec){

    if(k==1){
      ind.re<-c(ind.re,1: n.vec[1])
    }else{
      ind.re<- c(ind.re, (sum(n.vec[1:(k-1)])+1): sum(n.vec[1:k]))
    }

  }
  return(ind.re)
}
