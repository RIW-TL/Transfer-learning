

#' @title Split Target and Source Data
#'
#' @param Xdata0 covariate data in target
#' @param Ydata0 response data in target
#' @param Xdata1 covariate data of source
#' @param Ydata1 response data of source
#'
#' @return
#' \item{X01}{A list of length 3, where each element represents the first split-target covariate data and serves in constructing initial estimator}
#' \item{Y01}{A list of length 3, where each element represents the first split-target response data and serves in constructing initial estimator}
#' \item{X02}{A list of length 3, where each element represents the second split-target covariate data and serves in transfer learning}
#' \item{Y02}{A list of length 3, where each element represents the first split-target response data and serves in transfer learning}
#' \item{X.P1}{A list of length K, where each element represents the first split-source covariate data and serves in constructing initial estimators}
#' \item{Y.P1}{A list of length K, where each element represents the first split-source response data and serves in constructing initial estimators}
#' \item{X.P2}{A list of length K, where each element represents the second split-source covariate data and serves in kernel density estimation}
#' \item{Y.P2}{A list of length K, where each element represents the second split-source response data and serves in kernel density estimation}
#' \item{X.P3}{A list of length K, where each element represents the third split-source covariate data and serves in transfer learning}
#' \item{Y.P3}{A list of length K, where each element represents the third split-source response data and serves in transfer learning}
#' @export
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#'
#' # data splitting
#' fit = fit.split(Xdata0,Ydata0,Xdata1,Ydata1)
#' X01 = fit$X01;Y01 = fit$Y01
#' X02 = fit$X02;Y02 = fit$Y02
#' X.P1 = fit$X.P1;Y.P1 = fit$Y.P1
#' X.P2 = fit$X.P2;Y.P2 = fit$Y.P2
#' X.P3 = fit$X.P3;Y.P3 = fit$Y.P3
fit.split = function(Xdata0,Ydata0,Xdata1,Ydata1){

  n0 = nrow(Xdata0)
  K = length(Xdata1)
  n.vec = rep(0,K)
  for (k in 1:K) {n.vec[k] = nrow(Xdata1[[k]])}


  # target data splitting
  X01 = Y01 = X02 = Y02 = list()
  for (j in 1:3) {

    id = ((j - 1)*floor(n0/3) + 1):(j*floor(n0/3))
    X01[[j]] = Xdata0[-id,]
    Y01[[j]] = Ydata0[-id]
    X02[[j]] = Xdata0[id,]
    Y02[[j]] = Ydata0[id]
  }

  # source data splitting
  X.P1 = Y.P1 = X.P2 = Y.P2 = X.P3 = Y.P3 = list()

  for (k in 1:K) {

    X.P1[[k]] = Xdata1[[k]][1:floor(n.vec[k]/3),]
    X.P2[[k]] = Xdata1[[k]][(floor(n.vec[k]/3) + 1):floor(2*n.vec[k]/3),]
    X.P3[[k]] = Xdata1[[k]][(floor(2*n.vec[k]/3) + 1):n.vec[k],]

    Y.P1[[k]] = Ydata1[[k]][1:floor(n.vec[k]/3)]
    Y.P2[[k]] = Ydata1[[k]][(floor(n.vec[k]/3) + 1):floor(2*n.vec[k]/3)]
    Y.P3[[k]] = Ydata1[[k]][(floor(2*n.vec[k]/3) + 1):n.vec[k]]
  }

  return(list(X01 = X01,Y01 = Y01,
              X02 = X02,Y02 = Y02,
              X.P1 = X.P1,Y.P1 = Y.P1,
              X.P2 = X.P2,Y.P2 = Y.P2,
              X.P3 = X.P3,Y.P3 = Y.P3))

}
