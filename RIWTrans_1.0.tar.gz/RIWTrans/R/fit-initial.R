
#' @title Construct Initial Estimators for Target and Source Models
#' @description
#' Constructs initial estimators for the target model and source models
#' using penalized regression methods such as LASSO or SCAD
#'
#' @param Xdata01 the covariates data used in constructing target initial estimator
#' @param Ydata01 the response data used in constructing target initial estimator
#' @param X11 the covariates data used in constructing source initial estimators
#' @param Y11 the response data used in constructing source initial estimators
#' @param init the penalty type in constructing initial estimator. The type = "LASSO" or "SCAD".
#' By default, the penalty type is SCAD.
#'
#' @return
#' \item{beta0.initial.hat}{target initial estimator}
#' \item{beta1.initial.hat}{a p x K matrix whose k-th column denotes the initial estimator of the k-th source}
#' @export
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#'
#' # data splitting
#' fit = fit.split(Xdata0,Ydata0,Xdata1,Ydata1)
#' X01 = fit$X01;Y01 = fit$Y01
#' X02 = fit$X02;Y02 = fit$Y02
#' X.P1 = fit$X.P1;Y.P1 = fit$Y.P1
#' X.P2 = fit$X.P2;Y.P2 = fit$Y.P2
#' X.P3 = fit$X.P3;Y.P3 = fit$Y.P3
#'
#' # construct initial estimators
#' fit = fit.initial(X01[[1]],Y01[[1]],X.P1,Y.P1)
#' beta0.initial.hat = fit$beta0.initial.hat
#' beta1.initial.hat = fit$beta1.initial.hat
fit.initial = function(Xdata01,Ydata01,X11,Y11,init = "SCAD"){

  p = ncol(Xdata01)
  K = length(X11)

  # initial estimator
  beta1.initial.hat = matrix(0,p,K)
  if(init == "SCAD"){

    fit = cv.ncvreg(Xdata01,Ydata01,family = "gaussian",penalty = "SCAD")
    beta0.initial.hat = fit$fit$beta[-1,fit$min]


    for (k in 1:K) {

      fit = cv.ncvreg(X11[[k]],Y11[[k]],family = "gaussian",penalty = "SCAD")
      beta1.initial.hat[,k] = fit$fit$beta[-1,fit$min]
    }
  }else{

    fit = cv.glmnet(Xdata01,Ydata01,family = "gaussian",alpha = 1)
    beta0.initial.hat = fit$fit$beta[-1,fit$min]

    for (k in 1:K) {

      fit = cv.glmnet(X11[[k]],Y11[[k]],family = "gaussian",alpha = 1)
      beta1.initial.hat[,k] = fit$fit$beta[-1,fit$min]
    }
  }

  return(list(beta0.initial.hat = beta0.initial.hat,
              beta1.initial.hat = beta1.initial.hat))

}


