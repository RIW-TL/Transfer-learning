#' @title RIW-TL Estimation for a Single Data Split
#'
#' @param X02 the split target covariates data used in
#' transfer learning
#' @param Y02 the split target response data used in
#' transfer learning
#' @param X12 the split source covariates data used in
#' kernel density estimation
#' @param Y12 the split source response data used in
#' kernel density estimation
#' @param X13 the split source covariates data used in
#' transfer learning
#' @param Y13 the split source response data used in
#' transfer learning
#' @param A the thresholding parameter in sample selection, for stable weights
#' @param M the thresholding parameter in sample selection, for high-quality samples
#' @param TU the thresholding parameter in sample selection, for alternative RIW-TL-U
#' @param beta0.initial.hat target initial estimator
#' @param beta1.initial.hat p x K matrix that the k-th column denotes the initial estimator of k-th source
#
#' @return
#' \item{beta_RIW_TL}{The RIW-TL estimator in one data-split}
#' \item{beta_RIW_TL_U}{The final RIW-TL-U estimator in one data-split}
#' @importFrom ks kde
#' @importFrom glmnet cv.glmnet glmnet
#' @importFrom ncvreg cv.ncvreg
#' @importFrom stats coef predict
#' @export
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#'
#' # data splitting
#' fit = fit.split(Xdata0,Ydata0,Xdata1,Ydata1)
#' X01 = fit$X01;Y01 = fit$Y01
#' X02 = fit$X02;Y02 = fit$Y02
#' X.P1 = fit$X.P1;Y.P1 = fit$Y.P1
#' X.P2 = fit$X.P2;Y.P2 = fit$Y.P2
#' X.P3 = fit$X.P3;Y.P3 = fit$Y.P3
#'
#' # construct initial estimators
#' fit = fit.initial(X01[[1]],Y01[[1]],X.P1,Y.P1,init = "SCAD")
#' beta0.initial.hat = fit$beta0.initial.hat
#' beta1.initial.hat = fit$beta1.initial.hat
#'
#' fit = fit.RIW.DS(X02 = X02[[1]],Y02 = Y02[[1]],
#' X12 = X.P2,Y12 = Y.P2,
#' X13 = X.P3,Y13 = Y.P3,
#' A = 1,M = 1,TU = 2,
#' beta0.initial.hat,
#' beta1.initial.hat)
#' beta_RIW_TL = fit$beta_RIW_TL
#' beta_RIW_TL_U = fit$beta_RIW_TL_U

fit.RIW.DS = function(X02,Y02,X12,Y12,X13,Y13,
                      A,M,TU,
                      beta0.initial.hat,
                      beta1.initial.hat){

  p = ncol(X02)
  K = length(X12)

  # KDE and weighted sources data
  #-------------------------------------
  Ydata_star = Xdata_star = eta = list()
  Ydata_star_U = Xdata_star_U = list()
  error01.hat = error11.hat = list()

  for (k in 1:K) {

    error112.hat = Y12[[k]] - X12[[k]] %*% beta1.initial.hat[,k]
    kde.fit = kde(x = error112.hat[,1])

    error01.hat[[k]] = Y13[[k]] - X13[[k]] %*% beta0.initial.hat
    error11.hat[[k]] = Y13[[k]] - X13[[k]] %*% beta1.initial.hat[,k]

    # RIW-TL
    fenzi = (predict(kde.fit,x = error01.hat[[k]]) +
               predict(kde.fit,x = -error01.hat[[k]]))/2
    fenmu = predict(kde.fit,x = error11.hat[[k]])
    weight = fenzi/fenmu;weight[which(fenzi < 0 | fenmu <0)] = 0

    Ydata_star[[k]] = sqrt(weight)*Y13[[k]]
    Xdata_star_matrix = matrix(0,nrow(X13[[k]]),p)
    for (i in 1:nrow(X13[[k]])) {

      Xdata_star_matrix[i,] = sqrt(weight[i])*X13[[k]][i,]
    }
    Xdata_star[[k]] = Xdata_star_matrix


    # RIW-TL-U
    fenzi =  ifelse(abs(error01.hat[[k]]) <= TU, 1/(2*TU), 0)
    fenmu = predict(kde.fit,x = error11.hat[[k]])
    weight_U = fenzi/fenmu
    weight_U[which(fenzi < 0 | fenmu <0)] = 0

    Ydata_star_U[[k]] = sqrt(weight_U)*Y13[[k]]
    Xdata_star_matrix = matrix(0,nrow(X13[[k]]),p)
    for (i in 1:nrow(X13[[k]])) {

      Xdata_star_matrix[i,] = sqrt(weight_U[i])*X13[[k]][i,]
    }
    Xdata_star_U[[k]] = Xdata_star_matrix

    # contrast vectors adjusted by predictors
    eta[[k]] = X13[[k]] %*% (beta1.initial.hat[,k] - beta0.initial.hat)
  }


  # sample selection
  #-------------------------------------
  YY = Y_P = Y_U = Y02;XX = X_P = X_U = X02
  for (k in 1:K) {

    # RIW-TL
    id1 = which((abs(error11.hat[[k]]) <= A) & (abs(eta[[k]]) <= M))
    YY = c(YY,Ydata_star[[k]][id1])
    XX = rbind(XX,Xdata_star[[k]][id1,])

    # RIW-TL-U
    Y_U = c(Y_U,Ydata_star_U[[k]][id1])
    X_U = rbind(X_U,Xdata_star_U[[k]][id1,])
  }

  # weighted lasso optimization
  const = 0.5
  fit_F = glmnet(XX,YY,family = "gaussian",alpha = 1,
                 lambda = const*sqrt(log(p)/length(YY)))
  fit_F_U = glmnet(X_U,Y_U,family = "gaussian",alpha = 1,
                   lambda = const*sqrt(log(p)/length(Y_U)))

  beta_RIW_TL = coef(fit_F)[-1]
  beta_RIW_TL_U = coef(fit_F_U)[-1]

  return(list(beta_RIW_TL = beta_RIW_TL,
              beta_RIW_TL_U = beta_RIW_TL_U))
}

