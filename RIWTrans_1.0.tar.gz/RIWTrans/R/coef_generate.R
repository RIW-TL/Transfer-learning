#' @title Generate Regression Coefficients for Target and Source Models
#'
#' @param s sparsity level
#' @param size.A0 number of possible informative sources
#' @param d the magnitude of difference between beta_0 and beta_k in informative sources.
#' The smaller value of d implies the first size.A0 sources are more informative
#' @param q the magnitude of difference between beta_0 and beta_k in non-informative sources
#' @param p dimension of data
#' @param K number of sources
#' @param sig.beta true significant coefficient
#' @param sig.delta coefficients difference for each entry

#' @return
#' \item{W}{Sources coefficients matrix}
#' \item{beta0}{Coefficients in target model}
#' @export
#'
#' @examples
#' p = 100;s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' print(fit$beta0)
Coef.gen = function(s,d,q,p, size.A0, K, sig.beta, sig.delta){

  # target parameter
  beta0 = c(rep(sig.beta,s), rep(0, p - s))

  # source parameters
  W = matrix(0,p,K)
  for (k in 1:K) {W[,k] = beta0}

  for(k in 1:K){

    if(k <= size.A0){

        samp0<- sample((s + 1):p, d, replace=F)
        W[samp0,k] <-W[samp0,k] + rep(-sig.delta, d)

    }else{

        W[1:s,k] <- W[1:s,k] + rep(-sig.beta,s)
        samp1 <- sample((s + 1):p, q, replace = F)
        W[samp1,k] <-W[samp1,k] + rep(-sig.delta, q)
    }
  }

  return(list(W=W, beta0=beta0))
}
