#' @title RIW-TL Estimation via Data Splitting
#' @description
#' Implements the residual importance weighting transfer learning (RIW-TL)
#' algorithm proposed by Zhao et al. (2026) using a data-splitting procedure with user-specified tuning parameters
#'
#' @param Xdata0 covariate matrix in target data
#' @param Ydata0 response vector in target data
#' @param Xdata1 a list of length K, covariate matrix in source data
#' @param Ydata1 a list of length K, response vector in source data
#' @param A thresholding parameter for selecting samples with bounded weights
#' @param M thresholding parameter for selecting high-quality source samples
#' @param TU parameter used in alternative RIW-TL with uniform distribution
#' @param init The penalty type used in constructing initial estimators. init = "LASSO" or "SCAD"
#' @return
#' \item{beta_RIW_TL}{the estimated coefficients of RIW-TL estimator}
#' \item{beta_RIW_TL_U}{the estimated coefficients of RIW-TL-U estimator}
#' @export
#' @references Zhao, J., Zheng, S., & Leng, C. (2026). Residual Importance Weighted Transfer
#' Learning For High-dimensional Linear Regression. *Journal of the American
#' Statistical Association*. In Press.
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#' fit = fit.RIW(Xdata0,Ydata0,Xdata1,Ydata1,A = 1,M = 1,TU = 2)
#' beta_RIW_TL = fit$beta_RIW_TL
fit.RIW = function(Xdata0,Ydata0,Xdata1,Ydata1,A,M,TU,init = "SCAD"){

  n0 = nrow(Xdata0);p = ncol(Xdata0)

  K = length(Xdata1)

  # data splitting
  fit = fit.split(Xdata0,Ydata0,Xdata1,Ydata1)
  X01 = fit$X01;Y01 = fit$Y01
  X02 = fit$X02;Y02 = fit$Y02
  X.P1 = fit$X.P1;Y.P1 = fit$Y.P1
  X.P2 = fit$X.P2;Y.P2 = fit$Y.P2
  X.P3 = fit$X.P3;Y.P3 = fit$Y.P3


  # Part-1
  fit = fit.initial(X01[[1]],Y01[[1]],X.P1,Y.P1,init)
  beta0.initial.hat = fit$beta0.initial.hat
  beta1.initial.hat = fit$beta1.initial.hat
  fit1 = fit.RIW.DS(X02[[1]],Y02[[1]],
                    X12 = X.P2,Y12 = Y.P2,
                    X13 = X.P3,Y13 = Y.P3,
                    A,M,TU,
                    beta0.initial.hat,
                    beta1.initial.hat)

  # Part-2
  fit = fit.initial(X01[[2]],Y01[[2]],X.P2,Y.P2)
  beta0.initial.hat = fit$beta0.initial.hat
  beta1.initial.hat = fit$beta1.initial.hat
  fit2 = fit.RIW.DS(X02 = X02[[2]],Y02 = Y02[[2]],
                    X12 = X.P3,Y12 = Y.P3,
                    X13 = X.P1,Y13 = Y.P1,
                    A,M,TU,
                    beta0.initial.hat,
                    beta1.initial.hat)

  # Part-3
  fit = fit.initial(X01[[3]],Y01[[3]],X.P3,Y.P3,init)
  beta0.initial.hat = fit$beta0.initial.hat
  beta1.initial.hat = fit$beta1.initial.hat
  fit3 = fit.RIW.DS(X02 = X02[[3]],Y02 = Y02[[3]],
                    X12 = X.P1,Y12 = Y.P1,
                    X13 = X.P2,Y13 = Y.P2,
                    A,M,TU,
                    beta0.initial.hat,
                    beta1.initial.hat)


  beta_RIW_TL = (fit1$beta_RIW_TL + fit2$beta_RIW_TL + fit3$beta_RIW_TL)/3
  beta_RIW_TL_U = (fit1$beta_RIW_TL_U + fit2$beta_RIW_TL_U + fit3$beta_RIW_TL_U)/3

  return(list(beta_RIW_TL = beta_RIW_TL,
              beta_RIW_TL_U = beta_RIW_TL_U))
}
