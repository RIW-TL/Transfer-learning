
#' @title Generate Synthetic Target and Source Data
#' @description
#' Generates synthetic data sets for the target domain and multiple source domains
#' based on specified regression coefficients
#'
#' @param n0 sample size of target data
#' @param n1 sample size of source data
#' In this example, we assume that the sources have equal sample sizes
#' @param p dimension of data
#' @param W source coefficients matrix
#' @param beta0 target coefficients
#'
#' @return A list with components:
#' \item{Xdata0}{Covariate matrix for the target data}
#' \item{Ydata0}{Response vector for the target data}
#' \item{Xdata1}{List of covariate matrices for source data}
#' \item{Ydata1}{List of response vectors for source data}
#' @importFrom mvtnorm rmvnorm
#' @importFrom stats rnorm
#' @export
#'
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
data.generate = function(n0,n1,p,W,beta0){

  Sig.X = matrix(0,p,p)
  for (i in 1:p) {
    for (j in 1:p) {
      Sig.X[i,j] = 0.5^(abs(i-j))
    }
  }

  # Target data
  Xdata0 = rmvnorm(n0, rep(0, p), Sig.X)
  Ydata0 = Xdata0 %*% beta0 + rnorm(n0)

  # source data
  Ydata1 = Xdata1 = list()
  K = ncol(W)
  for (k in 1:K) {

    X = rmvnorm(n1, rep(0, p), Sig.X)
    Y = X %*% W[, k] + rnorm(n1)
    Xdata1[[k]] = X
    Ydata1[[k]] = Y
  }

  return(list(Xdata0 = Xdata0, Ydata0 = Ydata0,
              Xdata1 = Xdata1, Ydata1 = Ydata1))


}
