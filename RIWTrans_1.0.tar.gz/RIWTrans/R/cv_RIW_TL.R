
#' @title Cross-Validated RIW-TL Estimation
#' @description
#' Implements the residual importance weighting transfer learning (RIW-TL)
#' algorithm with tuning parameters selected via cross-validation
#' @param Xdata0 covariate matrix in target data
#' @param Ydata0 response vector in target data
#' @param Xdata1 a list of length K, covariate matrix in source data
#' @param Ydata1 a list of length K, response vector in source data
#' @param init The penalty type used in constructing initial estimators
#' @param A.range the range of parameter A. By default, A.range = c(0.5,1,1.5)
#' @param M.range the range of parameter M. By default, M.range = seq(0,4,1)
#' @param fold the number of folds in cross-validation. By default, fold = 5
#' @return
#' \item{beta_RIW_TL}{the estimated coefficients of RIW-TL estimator}
#' \item{beta_RIW_TL_U}{the estimated coefficients of RIW-TL-U estimator}
#' @export
#'
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#' fit = cv.RIW.TL(Xdata0,Ydata0,Xdata1,Ydata1)
#' beta_RIW_TL = fit$beta_RIW_TL
#' beta_RIW_TL_U = fit$beta_RIW_TL_U
cv.RIW.TL = function(Xdata0,Ydata0,Xdata1,Ydata1,init = "SCAD",
                     A.range = seq(0.5,1.5,0.5),
                     M.range = seq(0,4,1),
                     fold = 5){

  fit = hyper.select.cv(Xdata0,Ydata0,Xdata1,Ydata1,init,A.range,M.range,fold)

  ###########RIW-TL###################
  A = fit$A.opt;
  M = fit$M.opt;
  TU = A + M;
  fit1 = fit.RIW(Xdata0,Ydata0,Xdata1,Ydata1,A,M,TU,init)
  beta_RIW_TL = fit1$beta_RIW_TL

  ###########RIW-TL-U###################
  A = fit$A.opt.u;
  M = fit$M.opt.u;
  TU = A + M;
  fit1 = fit.RIW(Xdata0,Ydata0,Xdata1,Ydata1,A,M,TU,init)
  beta_RIW_TL_U = fit1$beta_RIW_TL_U

  return(list(beta_RIW_TL = beta_RIW_TL,
              beta_RIW_TL_U = beta_RIW_TL_U))
}
