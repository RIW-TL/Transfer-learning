#' @title Select Tuning Parameters via Cross-Validation
#'
#' @param Xdata0 covariate matrix in target data
#' @param Ydata0 response vector in target data
#' @param Xdata1 a list of length K, covariate matrix in source data
#' @param Ydata1 a list of length K, response vector in source data
#' @param init the penalty type used in constructing initial estimators
#' @param fold the number of folds in cross-validation. By default, fold = 5
#' @param A.range the range of parameter A. By default, A.range = seq(0.5,1.5,0.5)
#' @param M.range the range of parameter M. By default, M.range = seq(0,4,1)
#' @return
#' \item{A.opt}{the selected parameter A in RIW-TL}
#' \item{M.opt}{the selected parameter M in RIW-TL}
#' \item{A.opt.u}{the selected parameter A in RIW-TL-U}
#' \item{M.opt.u}{the selected parameter M in RIW-TL-U}
#' \item{cv.error.sum}{the errors grid for RIW-TL}
#' \item{cv.error.sum.u}{the errors grid for RIW-TL-U}
#' @export
#'
#' @examples
#' n0 = 150;n1 = 600;p = 100
#' s = 10;K = 5;q = 2*s
#' sig.beta = 1;sig.delta = 0.5
#' size.A0 = 3;d = 4
#' fit = Coef.gen(s,d,q,p, size.A0, K, sig.beta, sig.delta)
#' W = fit$W; beta0 = fit$beta0
#' data_gen = data.generate(n0,n1,p,W,beta0)
#' Xdata0 = data_gen$Xdata0;Ydata0 = data_gen$Ydata0
#' Xdata1 = data_gen$Xdata1;Ydata1 = data_gen$Ydata1
#' fit = hyper.select.cv(Xdata0,Ydata0,Xdata1,Ydata1)
#' A.opt = fit$A.opt
#' M.opt = fit$M.opt
#' A.opt.u = fit$A.opt.u
#' M.opt.u =fit$M.opt.u
hyper.select.cv = function(Xdata0,Ydata0,Xdata1,Ydata1,init = "SCAD",
                           A.range = seq(0.5,1.5,0.5),
                           M.range = seq(0,4,1),
                           fold = 5){

  n0 = nrow(Xdata0)
  p = ncol(Xdata0)
  K = length(Xdata1)

  cv.error.sum = cv.error.sum.u = matrix(0,length(A.range),length(M.range))
  for (f in 1:fold) {

        # validation set
        val.id = ((f - 1)*floor(n0/fold) + 1):(f*floor(n0/fold))
        X0.val = Xdata0[val.id,]
        y0.val = Ydata0[val.id]

        # training set
        X0.use = Xdata0[-val.id,]
        y0.use = Ydata0[-val.id]
        #-----------------------------------------------------------

        # data splitting
        fit = fit.split(X0.use,y0.use,Xdata1,Ydata1)
        X01 = fit$X01;Y01 = fit$Y01
        X02 = fit$X02;Y02 = fit$Y02
        X.P1 = fit$X.P1;Y.P1 = fit$Y.P1
        X.P2 = fit$X.P2;Y.P2 = fit$Y.P2
        X.P3 = fit$X.P3;Y.P3 = fit$Y.P3
        #-----------------------------------------------------------

        # construct initial estimator
        fit = fit.initial(X01[[1]],Y01[[1]],X.P1,Y.P1,init)
        beta0.initial.hat.1 = fit$beta0.initial.hat
        beta1.initial.hat.1 = fit$beta1.initial.hat

        fit = fit.initial(X01[[2]],Y01[[2]],X.P2,Y.P2,init)
        beta0.initial.hat.2 = fit$beta0.initial.hat
        beta1.initial.hat.2 = fit$beta1.initial.hat

        fit = fit.initial(X01[[3]],Y01[[3]],X.P3,Y.P3,init)
        beta0.initial.hat.3 = fit$beta0.initial.hat
        beta1.initial.hat.3 = fit$beta1.initial.hat
        #-----------------------------------------------------------
        cv.error = cv.error.u = matrix(0,length(A.range),length(M.range))
        for (a in seq_along(A.range)) {
          for (m in seq_along(M.range)) {

            A = A.range[a]
            M = M.range[m]
            TU = A + M

            # Part-1

            fit1 = fit.RIW.DS(X02 = X02[[1]],Y02 = Y02[[1]],
                              X12 = X.P2,Y12 = Y.P2,
                              X13 = X.P3,Y13 = Y.P3,
                              A,M,TU,
                              beta0.initial.hat.1,
                              beta1.initial.hat.1)
            beta_RIW_TL = fit$beta_RIW_TL
            beta_RIW_TL_U = fit$beta_RIW_TL_U

            # Part-2
            fit2 = fit.RIW.DS(X02 = X02[[2]],Y02 = Y02[[2]],
                              X12 = X.P3,Y12 = Y.P3,
                              X13 = X.P1,Y13 = Y.P1,
                              A,M,TU,
                              beta0.initial.hat.2,
                              beta1.initial.hat.2)

            # Part-3
            fit3 = fit.RIW.DS(X02 = X02[[3]],Y02 = Y02[[3]],
                              X12 = X.P1,Y12 = Y.P1,
                              X13 = X.P2,Y13 = Y.P2,
                              A,M,TU,
                              beta0.initial.hat.3,
                              beta1.initial.hat.3)

            beta_RIW_TL = (fit1$beta_RIW_TL + fit2$beta_RIW_TL + fit3$beta_RIW_TL)/3
            beta_RIW_TL_U = (fit1$beta_RIW_TL_U + fit2$beta_RIW_TL_U + fit3$beta_RIW_TL_U)/3

            #-----------------------------------------------------------
            # compute the cv loss
            cv.error[a,m] = sum((y0.val - X0.val %*% beta_RIW_TL)^2)
            cv.error.u[a,m] = sum((y0.val - X0.val %*% beta_RIW_TL_U)^2)
          }
        }

        cv.error.sum = cv.error.sum + cv.error
        cv.error.sum.u = cv.error.sum.u + cv.error.u
      }

  min.id = which(cv.error == min(cv.error),arr.ind = TRUE)
  min.id.u = which(cv.error.u == min(cv.error.u),arr.ind = TRUE)

  return(list(A.opt = A.range[min.id[1,1]],
              M.opt = M.range[min.id[1,2]],
              cv.error = cv.error,
              A.opt.u = A.range[min.id.u[1,1]],
              M.opt.u = M.range[min.id.u[1,2]],
              cv.error.sum = cv.error.sum,
              cv.error.sum.u = cv.error.sum.u))
}
